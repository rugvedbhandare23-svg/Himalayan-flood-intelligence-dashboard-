# Himalayan Flood Intelligence Dashboard

A responsive, single-page dashboard prototype for exploring simulated Himalayan flood impacts, settlement connectivity, hospital access, roads and bridges, and satellite-acquisition metadata.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

No build step or package installation is required. The dashboard loads the Archivo font from Google Fonts; if you are offline, it falls back to system fonts.

## Publish with GitHub Pages

1. Create a new repository on GitHub (for example, `himalayan-flood-intelligence-dashboard`).
2. Upload `index.html`, `README.md`, and `LICENSE` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/(root)`, then save.
6. After GitHub Pages finishes publishing, use the URL shown in the Pages settings.

## Important data note

**This is a demonstration prototype.** The dashboard explicitly uses simulated demo data and generates repeatable illustrative results based on the selected area and date. Satellite acquisition metadata, flood extents, affected buildings, village populations, road closures, and hospital statuses are not live observations or verified emergency information. Do not use this dashboard for operational decisions, evacuation planning, or public safety without replacing the simulation with validated data and appropriate review.

## Current features

- Area and event-date inputs
- Flood extent visualization and map layers
- Settlement status and connectivity explanations
- Hospital and town accessibility summaries
- Affected road and bridge listing
- Plain-text situation report export
- Responsive layout and light/dark theme support

## License

MIT. See `LICENSE`.
